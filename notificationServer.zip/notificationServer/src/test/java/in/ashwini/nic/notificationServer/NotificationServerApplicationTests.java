package in.ashwini.nic.notificationServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
